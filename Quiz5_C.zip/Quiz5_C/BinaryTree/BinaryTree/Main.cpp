/*
This program contains a quiz 5 by daniel Reyes, tris program create a binary tree and search if a node contain an number input by for a user.
*/

#include <stdio.h>
#include "BinaryTree.h"

int main()
{
	printf("Binary Tree\n");

	//Insert a values for tree
	printf("Please enter a bunch of numbers. -100 to stop\n");
	int num;
	while (true) {
		scanf_s("%d", &num);

		if (num == -100) break;
		Insert(num);
	}

	//Print values for tree
	Print(root);
	printf("\n--------------------------\n");

	//search function with input value(search_value)
	int search_value;
	printf("Please insert a number, to see if it belongs to our tree. \n");
	scanf_s("%d", &search_value);
	
	bool found=Search(search_value, root);
	if (found)
		printf("Yes, the number %d is contained in the tree", search_value);
	else
		printf("No, the tree does not contain the number %d", search_value);



}

