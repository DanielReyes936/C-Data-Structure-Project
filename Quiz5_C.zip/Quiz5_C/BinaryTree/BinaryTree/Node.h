#pragma once

struct Node {
	int Num;
	struct Node* Left;
	struct Node* Right;
};
