#pragma once

#include <stdlib.h>
#include "Node.h"

struct Node* head = NULL;
struct Node* temp = NULL;

void AddNode(int n) {
    /*
    * Three-step process we used in class to add a node to a list
    */
    // 1. Create a new node
    temp = (struct Node*)malloc(sizeof(struct Node));

    // 2. Initialize the new node
    temp->num = n;
    temp->next = head;

    // 3. Link new node into the list
    head = temp;
}

int RemoveLastNode() {
    if (head == NULL) {
        return NULL;
    }

    // Step 1: Extract the number from the node
    int savedNumber = head->num;

    // Step 2: Save the position of the top node 
    temp = head;

    // Step 3: Update Head to point to the next node
    head = head->next;

    // Step 4: Delete the node
    free(temp);

    return savedNumber;
}

int RemoveFirstNode() {
    // Please implement this function for Assignment 3:

    // Your Dequeue() method inside Queue.h will need to call
    // RemoveFirstNode()

    //Save the position of the top node 
    temp = head;

    while (temp->next != NULL) {

        temp = temp->next;

    }
    //Extract the number from the node
    int savedNumber = temp->num;

    return savedNumber;

}

void ShowList(struct Node* hd) {
    temp = hd;  // Charmi's idea, remember?

    // b. print the rest of the list
    while (temp->next != NULL) {
        printf("%d ", temp->num);
        temp = temp->next;

    }
    // then print the list headed by the next node
    ShowList(temp);
}

void Show() {
    printf("\n\nNew List contents is :\n\n");
    ShowList(head);

}

void List(struct Node* hd) {
    temp = hd;  // Charmi's idea, remember?
    if (temp == NULL) {
        // We are at the end of the list, 
        // nothing left to show so just return 
        return;
    }

    // If we reach this point, the list is not empty, so:
    // a. print the current node
    printf("%d ", temp->num);
    // b. print the rest of the list
    temp = temp->next; // Move temp to the next node
    List(temp); // then print the list headed by the next node
}

