/*This program corresponds to Assignment3, coded by Daniel Reyes. This program infinitely stores even numbers, When you finish entering your values, insert  -100.
* This program Delete first and last node.
*/

#include <stdio.h>
#include "LinkedList.h"
#include "Stack.h"
#include "Queue.h"

int main()

{
    int value;

    printf("Insert random numbers, every odd number you enter will be stored.\n");
    printf("When you finish entering your values, insert  -100.\n");
    printf("Please enter an number: \n");

    //Loop infinitive for insert a values
    for (int i = 0; i >= 0; i++) {
        scanf_s("%d", &value);

        //Condition for add value in my Node

        if (value != -100)

            AddNode(value);

        //Condition for end Program

        if (value == -100)

            break;

        else

            continue;
    }


    //Print values
    printf("\n--------------------------------------");
    printf("\n\nThe List contains: ");
    List(head);
    printf("\n--------------------------------------\n");
    printf("\n\nthe removed nodes are: ");
    printf("\n\nThe Last node is: ");
    printf("%d\n", Pop());
    printf("\n\nThe first Node is: ");
    printf("%d\n", DeQueue());
    printf("--------------------------------------");
    Show();
    









}