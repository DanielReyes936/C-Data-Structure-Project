#pragma once
#include "LinkedList.h"
void EnQueue(int num) {

	//TODO: Add the number num into a queue
	//Good news: we can use a linked list for this
	AddNode(num);

}

int DeQueue() {

	//TODO: Retrieve a number from the queue
	int num = RemoveFirstNode();
	return num;
}
