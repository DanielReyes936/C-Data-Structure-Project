#pragma once
#include "LinkedList.h"
#include <stdio.h>


/*
	A STACK needs to support two types of operation:

		Push(int num) which will put num into the stack
		Pop()  which will remove the item at the top and return it

*/

void Push(int num) {
	AddNode(num);
	//printf("Pushed %d into stack\n", num);
}

int Pop() {
	int num = RemoveLastNode();
	return num;
}

