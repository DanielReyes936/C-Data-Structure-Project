/*
This program is by Daniel Reyes
The principal funtion is delete a node in binary tree.
If the user insert -100, this program stop.
*/
#include <stdio.h>
#include <stdlib.h>
#include "Node.h"
#include "BinaryTree.h"

int main()
{
    printf("Binary Tree\n");

    //Star program
    printf("Please enter a bunch of numbers. -100 to stop\n");
    struct node* root = NULL;
    int num;
    while (true) {
        scanf_s("%d", &num);

        if (num == -100) break;

        //Insert node
        root = insert(root, num);

    }

    printf("Inorder traversal of the given tree \n");
    inorder(root);

    //Insert node to delete 
    while (true) {
        printf("\nEnter a number to Delete: ");
        scanf_s("%d", &num);
        if (num == -100) break;
        printf("Delete %d", num);
        root = deleteNode(root, num);

        //if root is NULL, the binary tree don't have a node.
        if (root == NULL) {
            printf("\nThe tree no contains items to delete.");
            break;
        }
        printf("\nInorder traversal of the modified tree \n");
        inorder(root);
    }

}