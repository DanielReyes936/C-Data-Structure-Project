#pragma once

struct node {
    int Num;
    struct node* Left, * Right;
};
