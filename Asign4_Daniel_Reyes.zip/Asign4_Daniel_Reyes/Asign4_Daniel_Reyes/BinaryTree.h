#pragma once

struct node* newNode(int item)
{
    struct node* temp
        = (struct node*)malloc(sizeof(struct node));
    temp->Num = item;
    temp->Left = temp->Right = NULL;
    return temp;
}

//Print function
void inorder(struct node* root)
{
    if (root != NULL) {
        inorder(root->Left);
        printf("%d ", root->Num);
        inorder(root->Right);
    }
}

//Insert Node
struct node* insert(struct node* node, int key)
{

    if (node == NULL)
        return newNode(key);


    if (key < node->Num)
        node->Left = insert(node->Left, key);
    else
        node->Right = insert(node->Right, key);


    return node;
}

//Search minValue
struct node* minValueNode(struct node* node)
{
    struct node* current = node;

    /* loop down to find the leftmost leaf */
    while (current && current->Left != NULL)
        current = current->Left;

    return current;
}

//Delete Function
struct node* deleteNode(struct node* root, int key)
{

    if (root == NULL)
        return root;


    if (key < root->Num)
        root->Left = deleteNode(root->Left, key);

    else if (key > root->Num)
        root->Right = deleteNode(root->Right, key);


    else {
        // node with only one child or no child
        if (root->Left == NULL) {
            struct node* temp = root->Right;
            free(root);
            return temp;
        }
        else if (root->Right == NULL) {
            struct node* temp = root->Left;
            free(root);
            return temp;
        }

        // node with two children: 
        struct node* temp = minValueNode(root->Right);


        root->Num = temp->Num;

        // Delete the inorder successor
        root->Right = deleteNode(root->Right, temp->Num);
    }
    return root;
}
