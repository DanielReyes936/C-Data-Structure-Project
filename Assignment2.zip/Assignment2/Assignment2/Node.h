#pragma once

struct Node {
    int num;
    struct Node* next;
};