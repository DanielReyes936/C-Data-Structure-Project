/*This program corresponds to assignment number 2, coded by Daniel Reyes. This program infinitely stores even numbers, to end the program the user must insert the number -100.
*/

#include <stdio.h>
#include "LinkedList.h"

int main()

{
    int value;

    printf("Insert random numbers, every odd number you enter will be stored.\n");
    printf("If you enter -100 the program ends.\n");
    printf("Please enter an number: \n");

    //Loop infinitive for insert a values
    for (int i = 0; i >= 0; i++) {  
        scanf_s("%d", &value);

        //Condition for add value in my Node

        if (value % 2 == 0 && value > 0) 

            AddNode(value);

        //Condition for end Program

        if (value == -100) 

            break;

        else

            continue;

    }

    //Print values

    printf("\n\nThe list of stored even numbers is: ");

    ShowList(head);

}