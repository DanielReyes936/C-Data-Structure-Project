﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace Assign2_reyesnan
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Data data = new Data();
        public MainWindow()
        {
            InitializeComponent();
        }
        private void btnLoadAllProducts_Click(object sender, RoutedEventArgs e)
        {
            grdProducts.ItemsSource = data.GetAllProducts().DefaultView;
        }
        private void btnFind_Click(object sender, RoutedEventArgs e)
        {
            grdProducts.ItemsSource = data.GetProductByCategoryId(txtCategoryId.Text).DefaultView;
            
            if ((int.Parse(txtCategoryId.Text))>8 || (int.Parse(txtCategoryId.Text))< 1)
            {
            
                MessageBox.Show("Invalid Category ID. Please try again", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }
        private void btnClearData_Click(object sender, RoutedEventArgs e)
        {
            txtCategoryId.Text = "";
        }
        private void btnReviewCategory_Click(object sender, RoutedEventArgs e)
        {
            ReviewCategories win2 = new ReviewCategories();
            win2.Show();
        }
    }
}
