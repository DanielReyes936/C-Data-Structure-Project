﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Assign2_reyesnan
{
    /// <summary>
    /// Interaction logic for ReviewCategories.xaml
    /// </summary>
    public partial class ReviewCategories : Window
    {
        public ReviewCategories()
        {
            InitializeComponent();
        }
        private void btnLoadData_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection conn = new SqlConnection(Data.ConnectionStr);
            string query = "Select CategoryID,CategoryName from Categories";
            SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
            DataSet ds = new DataSet();

            adapter.Fill(ds);

            DataTable tblCategories = ds.Tables[0];
            

            grdCategories.ItemsSource = tblCategories.DefaultView;
            
        }
    }
}
