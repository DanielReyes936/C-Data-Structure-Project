/*This program corresponds to MidTerm, coded by Daniel Reyes. This program infinitely stores even numbers, When you finish entering your values, insert  -100.
* This code was reused from my assignment number 2 and modified as required by the teacher.
*/

#include <stdio.h>
#include "LinkedList.h"

int main()

{
    int value;
    
    printf("Insert random numbers, every odd number you enter will be stored.\n");
    printf("When you finish entering your values, insert  -100.\n");
    printf("Please enter an number: \n");

    //Loop infinitive for insert a values
    for (int i = 0; i >= 0; i++) {  
        scanf_s("%d", &value);
        
        //Condition for add value in my Node

        if (value % 3 == 0 && value > 0 )
            
            AddNode(value);
           
        //Condition for end Program

        if (value == -100) 

            break;
        
        else

            continue;

    }
    

    //Print values

    printf("\n\nThe list of stored even numbers is: ");
    ShowList(head);

    //Print the largest node

    printf("\nThe value Max : ");
    ShowMax(head);

    
    
   


}