#pragma once
#include <stdio.h>
#include <stdlib.h>
#include "Node.h"

struct Node* CreateNode(int);
void InsertOnSubtree(int, struct Node*);

struct Node* root = NULL;
struct Node* tmp = NULL;

struct Node* CreateNode(int num) {
	struct Node* n = (struct Node*)malloc(sizeof(struct Node));
	n->Num = num;
	n->Left = NULL;
	n->Right = NULL;
	return n;
}

void Insert(int num) {
	if (root == NULL) {
		root = CreateNode(num);
		return;
	}
	InsertOnSubtree(num, root);
}

void InsertOnSubtree(int num, struct Node* top) {
	if (num < top->Num) {
		if (top->Left == NULL) {
			top->Left = CreateNode(num);
			return;
		}
		InsertOnSubtree(num, top->Left);
	}
	else {
		if (top->Right == NULL) {
			top->Right = CreateNode(num);
			return;
		}
		InsertOnSubtree(num, top->Right);
	}
}

// Strategy 1: Check first before trying to print
void Print(struct Node* top) {
	if (top->Left != NULL) {
		Print(top->Left); // not executed (skipped)
	}
	printf("%d ", top->Num); // 0
	if (top->Right != NULL) {
		Print(top->Right); // skipped
	}
}

// Strategy 2: Print anyway, knowing it can be null,
// and handle to null inside the print
void Print2(struct Node* top) {
	if (top == NULL) return;
	Print2(top->Left); 
	printf("%d ", top->Num);
	Print2(top->Right);
}
